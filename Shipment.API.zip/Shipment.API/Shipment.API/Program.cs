using Shipment.BusinessLogic;
using Shipment.BusinessLogic.Interface;
using Shipment.DataAccess;
using Shipment.DataAccess.Interfaces;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

builder.Services.AddScoped<IShipmentBusinessLogic, ShipmentBusinessLogic>();
builder.Services.AddScoped<IShipmentDataAccess, ShipmentDataAccess>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
