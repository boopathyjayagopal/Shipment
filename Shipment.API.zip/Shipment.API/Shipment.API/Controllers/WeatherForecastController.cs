using Microsoft.AspNetCore.Mvc;
using Shipment.BusinessLogic;
using Shipment.BusinessLogic.Interface;
using System.Threading.Tasks;

namespace Shipment.API.Controllers
{
    [ApiController]
    [Route("/api/v1/[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly IShipmentBusinessLogic _shipmentBusinessLogic;
        public WeatherForecastController(IShipmentBusinessLogic shipmentBusinessLogic) 
        {
            _shipmentBusinessLogic=shipmentBusinessLogic;
        }        

        [HttpGet(Name = "shipment")]
        public async Task<Shipment.Models.Shipment> GetShipment([FromQuery]string Id)
        {
            try
            {
                return await _shipmentBusinessLogic.GetShiment(Id);
            }
            catch (Exception)
            {
                throw;
            }            
        }
        [HttpPost(Name = "shipment-preset")]
        public async Task<int> AddShipment(Shipment.Models.Shipment shipment)
        {
            try
            {
                if(ModelState.IsValid)
                    return await _shipmentBusinessLogic.AddShipment(shipment);
                else
                    return 0;
            }
            catch (Exception)
            {
                throw;
            }
           
        }
    }
}
