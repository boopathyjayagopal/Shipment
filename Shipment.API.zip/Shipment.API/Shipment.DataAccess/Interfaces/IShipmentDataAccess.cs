﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shipment.DataAccess.Interfaces
{
    public interface IShipmentDataAccess
    {
        Task<int> AddShipment(Shipment.Models.Shipment shipment);

        Task<Shipment.Models.Shipment> GetShiment(string Id);
    }
}
