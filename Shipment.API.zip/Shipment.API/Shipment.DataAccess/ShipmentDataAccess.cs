﻿using Shipment.DataAccess.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Shipment.DataAccess
{
    public class ShipmentDataAccess : IShipmentDataAccess
    {
        public Task<int> AddShipment(Models.Shipment shipment)
        {
            return Task.FromResult(1);
        }

        public Task<Shipment.Models.Shipment> GetShiment(string Id)
        {
            return Task.FromResult( new Shipment.Models.Shipment {
                UserId=1,
                ActualWeight=100,
                Diemension = new Models.ShipmentDiemension
                {
                    Breadth=100,
                    Length=100,
                    Width=100
                },
                Service = Models.ServiceType.Courier
            });
        }
    }
}
