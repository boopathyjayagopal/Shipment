﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace Shipment.Models
{
    public class ShipmentDiemension
    {
        [Required]
        [Range(0.01, 70.00, ErrorMessage = "Length must be bet")]
        public int Length { get; set; }
        [Required]
        [Range(0.01, 70.00, ErrorMessage = "Breadth must be bet")]
        public int Breadth { get; set; }
        [Required]
        [Range(0.01, 70.00, ErrorMessage = "Width must be bet")]
        public int Width { get; set; }

        public double Volume
        {
            get
            {
                return Length * Breadth * Width;
            }
        }
        public double DimensionalWeight
        {
            get
            {
                return Math.Ceiling(Volume/139);
            }
        }
    }
}
