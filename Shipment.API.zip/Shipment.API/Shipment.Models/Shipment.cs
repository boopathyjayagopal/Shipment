﻿using System.ComponentModel.DataAnnotations;

namespace Shipment.Models
{
    public class Shipment
    {
        public int UserId { get; set; }
        public string PresetName { get; set; } = string.Empty;
        [Required]
        [Range(0.01, 70.00, ErrorMessage = "Length must be bet")]
        public double ActualWeight { get; set; }
        public ShipmentDiemension Diemension { get; set; }
        public ServiceType Service { get; set; }

        public Shipment()
        {
            Diemension = new ShipmentDiemension();
        }

        public double BillableWeight
        {
            get
            {
                return Math.Max(this.Diemension.DimensionalWeight, ActualWeight);
            }
        }
    }

    public enum ServiceType
    {
        Cargo = 1,
        Courier = 2
    }
}
