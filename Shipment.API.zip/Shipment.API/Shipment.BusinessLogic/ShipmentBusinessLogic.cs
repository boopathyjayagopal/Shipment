﻿using Shipment.BusinessLogic.Interface;
using Shipment.DataAccess;
using Shipment.DataAccess.Interfaces;
using Shipment.Models;

namespace Shipment.BusinessLogic
{
    public class ShipmentBusinessLogic : IShipmentBusinessLogic
    {
        private readonly IShipmentDataAccess _shipmentRepository;
        public ShipmentBusinessLogic(IShipmentDataAccess shipmentRepository) 
        {
            _shipmentRepository = shipmentRepository;
        }
        public async Task<int> AddShipment(Models.Shipment shipment)
        {
            try
            {                
                return await _shipmentRepository.AddShipment(shipment);
            }
            catch (Exception)
            {

                throw;
            }            
        }

        public async Task<Shipment.Models.Shipment> GetShiment(string Id)
        {
            try
            {
                return await _shipmentRepository.GetShiment(Id);
            }
            catch (Exception)
            {

                throw;
            }            
        }
    }
}
