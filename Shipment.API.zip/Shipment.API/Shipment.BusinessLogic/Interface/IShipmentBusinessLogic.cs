﻿using Shipment.Models;
namespace Shipment.BusinessLogic.Interface
{
    public interface IShipmentBusinessLogic
    {
        Task<int> AddShipment(Shipment.Models.Shipment shipment);

        Task<Shipment.Models.Shipment> GetShiment(string Id);
    }
}
